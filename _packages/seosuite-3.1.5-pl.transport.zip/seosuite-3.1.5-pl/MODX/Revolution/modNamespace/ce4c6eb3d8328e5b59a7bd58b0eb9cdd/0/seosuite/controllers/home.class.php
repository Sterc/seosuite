<?php
use Sterc\SeoSuite\Controllers\Home;

class SeoSuiteHomeManagerController extends Home
{
}
