<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'changelog' => 'Changelog for SEO Suite.

SEO Suite 3.1.8
- Fixing invalid date in sitemap for crawling when resources are created outside of the manager through imports/api\'s.


SEO Suite 3.1.7
==============
- Fixing issue when there is redirect to itself (when resource is moved)
- Updating log level from error to info.
- Remove Context-dropdown from all dialog windows, not from the redirect logic.
- Stop using the context_key logic when adding 404\'s from the frontend.
- Always add the full URL as the value for seosuite_url.url. We are aware that this will result in manual changes in the database, whenever we hange a context\'s domain.
- Show full URL\'s everywhere in the manager. When old URL\'s are missing a context_key or the full URL, then just leave it like that and have the user add the full URL themselves.
- Add clear-cache after drag/drop redirect creation in SEO Suite.
- When moving a resource from root-en to root-nl (both root) then no redirect will be made. Root-en to folder-nl does work. Folder-en to root-nl also works.
- When moving resource from Context1 to Context2, the original context_key will be set to Context2, while it should be Context1.
- Deprecate context field(s) for next major version in mapping file.
- Bump phpoffice/phpspreadsheet from 1.29.0 to 1.29.1 in /core/components/seosuite #122
- Fix Sitemap error message #115
- Add site_url as prefix only when redirect has context_key
- Prevent storing 404 url with context_key
- URLs where saved without old url from suggestions tab
- Fix saving redirect old url when created from 404 urls tab
- Better fix for excluding resource from sitemap (issue#97)
- Replace deprecated PHPExcel with PHPSpreadsheet
- Do not create redirect on resource drag/drop when resource does not have SeoSuite activated (issue#100)
- Several lexicon updates (all languages)
- Allow full URL matching when finding redirect
- Clean up setup process
- Add button to redirects grid for testing redirect
- Remove automatic context prefix when creating/updating redirect
- Allow adding redirects with full url
- Add check for full url redirect match when OnPageNotFound is triggered
- Remove automatic context prefix when creating/updating redirect
- Replace deprecated PHPExcel with PhpSpreadsheet
- Add system setting to control the position of the SEO Suite panel (top or bottom)
- Fix date display in redirects grid when date is empty/zero
- Fix sitemap error message (PR#115) thanks to @halftrainedharry
- Fix preview image (PR#117) thanks to @Boshnik
- Bumped dependencies
- Please note: 3.1.5 and 3.1.6 were interal releases which were never publicly released.

SEO Suite 3.1.4
==============
- Fix bug with tags in longtitle (issue#11)
- Fix link in the widget (issue#30)
- Fix favicon display (issue#53)
- Fix social image ratio in manager (issue#61)
- Place SEO section always to the bottom (issue#70)
- Fix empty twitter_site placeholder (issue#82)
- Fix excluding resource from sitemap (issue#97)
- Fix failed setupoptions resolver (PR#105)
- Fix mysql8 compatibility issues (PR#104, issue#69)

SEO Suite 3.1.3
==============
- Fix alternate links (PR#95)
- Replace htmlentities htmlspecialchars for unicode characters (PR#98)
- Refactor/fix translations for Facebook/Open Graph (issue#79, PR#99)
- Move SeoSuite panel under TVs when tvs_below_content is used (issue #79)
- Change server_protocol system setting to local method (issue #90)
- Fix redirect create processor to match logic from update processor.

SEO Suite 3.1.2
==============
- Fix default permissions (PR#86)
- Fix bootstrap file to prevent FrozenServiceException (fixes #87)
- Add redirects for child resources when changing parent uri and use_alias_path is set to true

SEO Suite 3.1.1-rc8
==============
- Improved search for redirects for urls with language prefixes, like "en/", "nl/", etc.

SEO Suite 3.1.1-rc6
==============
- Fix resolvers for install on MODX3
- PHP8 compatibility fixes
- Add german translation (PR#75)
- Fix spacing in trash icon (fixes #48)
- Fix dashboard widget error (fixes #80)
- Add migration tools to CMP for migrating V1, SEO Pro and SEO Tab.
- Fix table indexes
- Add listener for \'OnBabelDuplicate\'
- Fix default values for sitemap, searchable and canonical

SEO Suite 3.1.0
==============
- Full refactoring for MODX3 #67

SEO Suite 3.0.5
==============
- Fix changefreq values #60
- Render meta tags on resources created before seosuit was installed #63
- Make sure redirects are 301 by default #73
- Fix error when user have no access to some context #73
- Disable seoTab in install #73

SEO Suite 3.0.4
==============
- Add buttons `Suggestions excludes` and `Logging excludes`

SEO Suite 3.0.3
==============
- Fix blocked_words usage

SEO Suite 3.0.2
==============
- Fix hreflang attribute in alternate tag

SEO Suite 3.0.1
==============
- Fix sorting in CMP
- Fix prority in sitemap

SEO Suite 3.0.0
==============
- Fix MODX 3 compatibility

SEO Suite 2.0.6
==============
- Fix creating redirect when sorting within same parent
- Fixing sitemap settings save on resource tabs
- Fix 500 error when no resource is found

SEO Suite 2.0.5
==============
- Automatically add a 301 redirect when a resource is moved

SEO Suite 2.0.4
==============
- Fix wrong image URL in custom media source #35

SEO Suite 2.0.3
==============
- Skip arrays to avoid tons message in the logs #15
- Fix displaying meta keywords #21
- Replace attribute name to property for og:-metafields #25
- Add russian lexicon #28

SEO Suite 2.0.2
==============
- Fixed issue which caused rich text content fields to break #4 #5

SEO Suite 2.0.1
==============
- Fixed issue which didn\'t set the alternate placeholders properly
- Fixed keyword counter issue in combination with Ace
- Fixed issue which didn\'t save the new url when creating a new redirect
- Fixed incorrect formatted URL during SEO Tab migration
- Added system setting for marking alternate link as x-default

SEO Suite 2.0.0
==============
- Combined SEO Tab, SEO Pro and SEO Suite v1 into one powerful extra
- Added a dedicated SEO panel
- Added Social tab where OG and Twitter meta tags can be managed
- Improved search engine preview

SEO Suite 1.2.3
==============
- Removed license check

SEO Suite 1.2.2
==============
- Added some missing Dutch translations
- Fixed issue with incorrect redirect-cleanup script path
- Improved Dutch/English descriptions

SEO Suite 1.2.1
==============
- validate URL\'s before saving them
- Able to block URL\'s from being saved as redirect by system setting

SEO Suite 1.2.0
==============
- Added redirect created date
- Added redirect triggerd count & last time triggerd date
- Added cleanup cronjob which removes unresolved redirects which are older then 1 month and have been triggered just once

SEO Suite 1.1.2
==============
- Added indexes for improved performance

SEO Suite 1.1.1
==============
- Modstore/modmore compatibility

SEO Suite 1.1.0
==============
- Add limit to redirect suggestions shown in grid
- Add SeoSuiteUrl and try to find matches when OnPageNotFound is triggered and no SeoSuiteUrl object is found
- Add dashboard widget with 10 latest SeoSuite URLs
- Detect CSV file delimiter on import
- Add option to limit matches to related context of URL
- Update find suggestions method to add redirect when one match is found
- Add search by ID to resource combobox
- Add system setting (and cmp field) for excluding words from suggestion matching
- Add suggestions combobox to update url window

SEO Suite 1.0.1
==============
- Fix find-suggestions response message to notify if more than one redirect match
- Fix getSeoTabVersion function to check for correct package_name
- Fix grid getlist to show only first 10 redirect suggestions to prevent processor timeouts
- Fix url update processor to not break when not using SEO Tab as redirect handler

SEO Suite 1.0.0
==============
- Initial release.
',
    'setup-options' => 'seosuite-3.1.8-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'bdde30c6362f4d75d5b9272298c7e9b3',
      'native_key' => 'seosuite',
      'filename' => 'MODX/Revolution/modNamespace/b569224d304e91565deae5309cb148f7.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4bd9fd76b00272299dc966175d923c51',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/160e41a2d6e38514a6de0fa0260bff11.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e85316fc90dd23cb8311ba2d5c345e8d',
      'native_key' => 'seosuite.disabled_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/15ba54283a3135c95139ded9dc3d0708.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9909ff28ed593fa3d55ef31d3743649b',
      'native_key' => 'seosuite.exclude_words',
      'filename' => 'MODX/Revolution/modSystemSetting/7bf0b9de24d913af28eccc9ff41446e1.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '911481cc9386eca4852439b799b8aafb',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/aaf39640dacc53db420007c3b98d3316.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e8b2152f2ea034d06675d1d3dd29d6ba',
      'native_key' => 'seosuite.placeholder_plugin_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/f39bbe56ea90a9c768a577bfc428d255.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3531ef3b2d213538415d12348759cab1',
      'native_key' => 'seosuite.migration_finished',
      'filename' => 'MODX/Revolution/modSystemSetting/97c5bb426c142582cb211c4ed029de99.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '652cbf8cc200e5fb81ab4f38a5e35240',
      'native_key' => 'seosuite.user_name',
      'filename' => 'MODX/Revolution/modSystemSetting/6c9ef92a8dd761bf2ecfb269d5479e63.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4d77b78ff55c79e5809df7bf1ccf2f9f',
      'native_key' => 'seosuite.user_email',
      'filename' => 'MODX/Revolution/modSystemSetting/ebf184c0a8cf944ec6b01d1322e8dda1.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8a84c5ae0a59de91a59cb4eaf2d8fb2e',
      'native_key' => 'seosuite.default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/58e1a23cd2e2414f0afcf0d76709fbc4.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cf5416e4b11fc73a1e22da1c90f15eb9',
      'native_key' => 'seosuite.meta.field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/78389936b6354563d4106e7e549d36f5.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa333a357ecb9e5b0ffb5345c47671c3',
      'native_key' => 'seosuite.meta.default_meta_description',
      'filename' => 'MODX/Revolution/modSystemSetting/ee96ba0bac992fbed0798fed16886eb0.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0fe1bfb3b85a34cfc812507c2d4b39c5',
      'native_key' => 'seosuite.meta.default_meta_title',
      'filename' => 'MODX/Revolution/modSystemSetting/cc9d5ee200c11caad74450cc991273c8.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a81db0a8a75c15624342208038e99374',
      'native_key' => 'seosuite.meta.default_alternate_context',
      'filename' => 'MODX/Revolution/modSystemSetting/b40a7a4e1b03ab62ba320625072bb0e5.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3d666f372a8064fb4d8acd101d86e481',
      'native_key' => 'seosuite.meta.keywords_field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/5da1bd672d8371dd9bde81d5cb78c513.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '26590aa403dae0bc687cef961ffbce93',
      'native_key' => 'seosuite.meta.preview.length_desktop_description',
      'filename' => 'MODX/Revolution/modSystemSetting/dc9be6ec720dce31a995c5f82a334796.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f72cbd3a8dc0ca12942b7ebcfaee7ce7',
      'native_key' => 'seosuite.meta.preview.length_desktop_title',
      'filename' => 'MODX/Revolution/modSystemSetting/32d05af93fe6f2708a1e230e0c0218eb.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a22614c8312f26a92e1eb25bb5c64cb5',
      'native_key' => 'seosuite.meta.preview.length_mobile_description',
      'filename' => 'MODX/Revolution/modSystemSetting/16acd49c6ea44e43b2bc0c81428ec088.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b825aca08d7e46321e5ce072d47a505c',
      'native_key' => 'seosuite.meta.preview.length_mobile_title',
      'filename' => 'MODX/Revolution/modSystemSetting/243297045eec0a97a89058bb25fb28fc.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1f3b3388c0c68c057f4b141b587cfdca',
      'native_key' => 'seosuite.meta.searchengine',
      'filename' => 'MODX/Revolution/modSystemSetting/043c5e66c570d38055ef82dd2cc1aa33.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b769ebec62417e22a472ffc9025e056e',
      'native_key' => 'seosuite.meta.searchmode',
      'filename' => 'MODX/Revolution/modSystemSetting/4f0ec9dd9e128e9e7a4135adbc9af01a.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '88b8eca1601fecc29d8690c8d618aaa1',
      'native_key' => 'seosuite.sitemap.default_changefreq',
      'filename' => 'MODX/Revolution/modSystemSetting/65f13d248626f0e867cad8bbb6f6081e.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff8c40ce54dfb5ef1912e1b9c22eb176',
      'native_key' => 'seosuite.sitemap.default_priority',
      'filename' => 'MODX/Revolution/modSystemSetting/d1c2f5e4f87cc061bf4299039f8b9a35.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1aed7f784a668c8c28bccd99add88710',
      'native_key' => 'seosuite.sitemap.dependent_ultimateparent',
      'filename' => 'MODX/Revolution/modSystemSetting/32acc6b6dd51951fa8778a26271b5990.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '80e7d5aa5ecf87a090878a93a3b009f8',
      'native_key' => 'seosuite.sitemap.babel.add_alternate_links',
      'filename' => 'MODX/Revolution/modSystemSetting/a06759268280d6d5a72eadbfa4a7261b.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60a1151576e7fb5ddb9973c76e4883bc',
      'native_key' => 'seosuite.tab_social.og_types',
      'filename' => 'MODX/Revolution/modSystemSetting/be3f5fd3f5e50e1b85e7c22278bbf446.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bab0dcdb6b20c429ff3fb1f8b3ff6760',
      'native_key' => 'seosuite.tab_social.twitter_cards',
      'filename' => 'MODX/Revolution/modSystemSetting/11c3269a834cab15d0302778dc7c9248.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '07d16b1f74b99f69111192e602540c2d',
      'native_key' => 'seosuite.tab_social.twitter_creator_id',
      'filename' => 'MODX/Revolution/modSystemSetting/2b04d1098b4a8b8be48797b499a000ea.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '416e3ef1e42d15c55cbfb8156d11146b',
      'native_key' => 'seosuite.tab_social.default_og_image',
      'filename' => 'MODX/Revolution/modSystemSetting/77a46ab722c795863f5635f1e588cd13.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60fe665765a6f1819e1e4d0f9b7b41ac',
      'native_key' => 'seosuite.tab_social.default_twitter_image',
      'filename' => 'MODX/Revolution/modSystemSetting/d1c6e7aba6852208d924d703696f1bd5.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '328cae7891fb54cac6425500b7e6566c',
      'native_key' => 'seosuite.panel_position_top',
      'filename' => 'MODX/Revolution/modSystemSetting/3bf302eac877c59c4062e74f44510140.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'b2f91c07caf626d58bcac4f882511d9b',
      'native_key' => 'b2f91c07caf626d58bcac4f882511d9b',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/955206eb00943ca75ab80bc0a38f6916.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'adb4a84103a55eee7936ece5a638aba7',
      'native_key' => 'seosuite.menu.seosuite',
      'filename' => 'MODX/Revolution/modMenu/1cb01fcd0243713cb650274b63f4501b.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'c4c4d3b63e2c57ee069c0bfa8a70ddda',
      'native_key' => 'c4c4d3b63e2c57ee069c0bfa8a70ddda',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/a060da52fe7b2779e487fb1178b12b71.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '1b7c3feb45d717e5acbacf6456f40d0d',
      'native_key' => '1b7c3feb45d717e5acbacf6456f40d0d',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/8ed13b1e50b30e33043874857ee92655.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'b2efd4d206012b7e4590b91ecee1c482',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/564d4ec4c053855676f0bbe2e8875f27.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '5232f63558648a5a1a9fa0f0e4b67e63',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/b07b70bf6b637b46042ad2603a0dc5c3.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'bc0fe983a0933da7b9e3d4ce8532b575',
      'native_key' => 'bc0fe983a0933da7b9e3d4ce8532b575',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/a0c4fb03d58705d9d39beea50496ecd9.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'f77befc7bc5e0a10bc054c3479573931',
      'native_key' => 'f77befc7bc5e0a10bc054c3479573931',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/e3d61335c11c6f0849223fc7346da167.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '53f384c4b16531c0a9cedd96e18f6356',
      'native_key' => '53f384c4b16531c0a9cedd96e18f6356',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/20b5ec459083e5a7b957646a4401a54f.vehicle',
    ),
  ),
);