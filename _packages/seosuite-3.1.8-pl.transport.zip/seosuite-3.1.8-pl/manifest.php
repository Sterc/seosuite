<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'changelog' => 'Changelog for SEO Suite.

SEO Suite 3.1.8
==============
- Fix relation definitions in schema/models (PR#124)
- Fix URL redirect handling (PR#132)
- Fix trying to access array offset on true error (PR#139)
- Fix incorrect saving of access permissions (PR#142)
- Add cache busting for JS assets (PR#147)
- Add system setting for enable/disable 404 logging (PR#146)
- Hide tabs that are not needed when system setting is disabled (PR#146)
- Fix some lexicons (PR#146)

SEO Suite 3.1.7
==============
- Fixing issue when there is redirect to itself (when resource is moved)
- Updating log level from error to info.
- Remove Context-dropdown from all dialog windows, not from the redirect logic.
- Stop using the context_key logic when adding 404\'s from the frontend.
- Always add the full URL as the value for seosuite_url.url. We are aware that this will result in manual changes in the database, whenever we hange a context\'s domain.
- Show full URL\'s everywhere in the manager. When old URL\'s are missing a context_key or the full URL, then just leave it like that and have the user add the full URL themselves.
- Add clear-cache after drag/drop redirect creation in SEO Suite.
- When moving a resource from root-en to root-nl (both root) then no redirect will be made. Root-en to folder-nl does work. Folder-en to root-nl also works.
- When moving resource from Context1 to Context2, the original context_key will be set to Context2, while it should be Context1.
- Deprecate context field(s) for next major version in mapping file.
- Bump phpoffice/phpspreadsheet from 1.29.0 to 1.29.1 in /core/components/seosuite #122
- Fix Sitemap error message #115
- Add site_url as prefix only when redirect has context_key
- Prevent storing 404 url with context_key
- URLs where saved without old url from suggestions tab
- Fix saving redirect old url when created from 404 urls tab
- Better fix for excluding resource from sitemap (issue#97)
- Replace deprecated PHPExcel with PHPSpreadsheet
- Do not create redirect on resource drag/drop when resource does not have SeoSuite activated (issue#100)
- Several lexicon updates (all languages)
- Allow full URL matching when finding redirect
- Clean up setup process
- Add button to redirects grid for testing redirect
- Remove automatic context prefix when creating/updating redirect
- Allow adding redirects with full url
- Add check for full url redirect match when OnPageNotFound is triggered
- Remove automatic context prefix when creating/updating redirect
- Replace deprecated PHPExcel with PhpSpreadsheet
- Add system setting to control the position of the SEO Suite panel (top or bottom)
- Fix date display in redirects grid when date is empty/zero
- Fix sitemap error message (PR#115) thanks to @halftrainedharry
- Fix preview image (PR#117) thanks to @Boshnik
- Bumped dependencies
- Please note: 3.1.5 and 3.1.6 were interal releases which were never publicly released.

SEO Suite 3.1.4
==============
- Fix bug with tags in longtitle (issue#11)
- Fix link in the widget (issue#30)
- Fix favicon display (issue#53)
- Fix social image ratio in manager (issue#61)
- Place SEO section always to the bottom (issue#70)
- Fix empty twitter_site placeholder (issue#82)
- Fix excluding resource from sitemap (issue#97)
- Fix failed setupoptions resolver (PR#105)
- Fix mysql8 compatibility issues (PR#104, issue#69)

SEO Suite 3.1.3
==============
- Fix alternate links (PR#95)
- Replace htmlentities htmlspecialchars for unicode characters (PR#98)
- Refactor/fix translations for Facebook/Open Graph (issue#79, PR#99)
- Move SeoSuite panel under TVs when tvs_below_content is used (issue #79)
- Change server_protocol system setting to local method (issue #90)
- Fix redirect create processor to match logic from update processor.

SEO Suite 3.1.2
==============
- Fix default permissions (PR#86)
- Fix bootstrap file to prevent FrozenServiceException (fixes #87)
- Add redirects for child resources when changing parent uri and use_alias_path is set to true

SEO Suite 3.1.1-rc8
==============
- Improved search for redirects for urls with language prefixes, like "en/", "nl/", etc.

SEO Suite 3.1.1-rc6
==============
- Fix resolvers for install on MODX3
- PHP8 compatibility fixes
- Add german translation (PR#75)
- Fix spacing in trash icon (fixes #48)
- Fix dashboard widget error (fixes #80)
- Add migration tools to CMP for migrating V1, SEO Pro and SEO Tab.
- Fix table indexes
- Add listener for \'OnBabelDuplicate\'
- Fix default values for sitemap, searchable and canonical

SEO Suite 3.1.0
==============
- Full refactoring for MODX3 #67

SEO Suite 3.0.5
==============
- Fix changefreq values #60
- Render meta tags on resources created before seosuit was installed #63
- Make sure redirects are 301 by default #73
- Fix error when user have no access to some context #73
- Disable seoTab in install #73

SEO Suite 3.0.4
==============
- Add buttons `Suggestions excludes` and `Logging excludes`

SEO Suite 3.0.3
==============
- Fix blocked_words usage

SEO Suite 3.0.2
==============
- Fix hreflang attribute in alternate tag

SEO Suite 3.0.1
==============
- Fix sorting in CMP
- Fix prority in sitemap

SEO Suite 3.0.0
==============
- Fix MODX 3 compatibility

SEO Suite 2.0.6
==============
- Fix creating redirect when sorting within same parent
- Fixing sitemap settings save on resource tabs
- Fix 500 error when no resource is found

SEO Suite 2.0.5
==============
- Automatically add a 301 redirect when a resource is moved

SEO Suite 2.0.4
==============
- Fix wrong image URL in custom media source #35

SEO Suite 2.0.3
==============
- Skip arrays to avoid tons message in the logs #15
- Fix displaying meta keywords #21
- Replace attribute name to property for og:-metafields #25
- Add russian lexicon #28

SEO Suite 2.0.2
==============
- Fixed issue which caused rich text content fields to break #4 #5

SEO Suite 2.0.1
==============
- Fixed issue which didn\'t set the alternate placeholders properly
- Fixed keyword counter issue in combination with Ace
- Fixed issue which didn\'t save the new url when creating a new redirect
- Fixed incorrect formatted URL during SEO Tab migration
- Added system setting for marking alternate link as x-default

SEO Suite 2.0.0
==============
- Combined SEO Tab, SEO Pro and SEO Suite v1 into one powerful extra
- Added a dedicated SEO panel
- Added Social tab where OG and Twitter meta tags can be managed
- Improved search engine preview

SEO Suite 1.2.3
==============
- Removed license check

SEO Suite 1.2.2
==============
- Added some missing Dutch translations
- Fixed issue with incorrect redirect-cleanup script path
- Improved Dutch/English descriptions

SEO Suite 1.2.1
==============
- validate URL\'s before saving them
- Able to block URL\'s from being saved as redirect by system setting

SEO Suite 1.2.0
==============
- Added redirect created date
- Added redirect triggerd count & last time triggerd date
- Added cleanup cronjob which removes unresolved redirects which are older then 1 month and have been triggered just once

SEO Suite 1.1.2
==============
- Added indexes for improved performance

SEO Suite 1.1.1
==============
- Modstore/modmore compatibility

SEO Suite 1.1.0
==============
- Add limit to redirect suggestions shown in grid
- Add SeoSuiteUrl and try to find matches when OnPageNotFound is triggered and no SeoSuiteUrl object is found
- Add dashboard widget with 10 latest SeoSuite URLs
- Detect CSV file delimiter on import
- Add option to limit matches to related context of URL
- Update find suggestions method to add redirect when one match is found
- Add search by ID to resource combobox
- Add system setting (and cmp field) for excluding words from suggestion matching
- Add suggestions combobox to update url window

SEO Suite 1.0.1
==============
- Fix find-suggestions response message to notify if more than one redirect match
- Fix getSeoTabVersion function to check for correct package_name
- Fix grid getlist to show only first 10 redirect suggestions to prevent processor timeouts
- Fix url update processor to not break when not using SEO Tab as redirect handler

SEO Suite 1.0.0
==============
- Initial release.
',
    'setup-options' => 'seosuite-3.1.8-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '41c83057d30695c6b422f12c5ed4b474',
      'native_key' => 'seosuite',
      'filename' => 'MODX/Revolution/modNamespace/57f60aabb8ff28c974969272b8910680.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b02110e6b9c89d27f926ac3f406785db',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/0474fb4fae04188be7c58f58ffc63814.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c46c24f58bc7cbbd3964a92becb330c',
      'native_key' => 'seosuite.disabled_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/1a7f04dbcdefbeb72f26d411669691c5.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0a041cb50613dea11e89c8fc2c57d757',
      'native_key' => 'seosuite.exclude_words',
      'filename' => 'MODX/Revolution/modSystemSetting/d9b20e95852395e7f5e0c6b828f2960b.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b9bc4fc939445e63dde685d6f1ec8ef2',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/8a2197fcf7271c4ba73e804b27df6ed6.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '462ac3a823291360b302a337e4a7a5d6',
      'native_key' => 'seosuite.placeholder_plugin_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/a45923cd6b5db350861d6a708fdfe884.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ae638e6841cd1c82d1de16e7919a5e23',
      'native_key' => 'seosuite.migration_finished',
      'filename' => 'MODX/Revolution/modSystemSetting/daae78c008f0f9dea701d871f7b52f8b.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '00f74010447f3dd76b9c685a33e20b7d',
      'native_key' => 'seosuite.user_name',
      'filename' => 'MODX/Revolution/modSystemSetting/1bfc00bb2ab50ad110c61e392ea1dacf.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '73875b435b047b84ed5bd4bf4025b905',
      'native_key' => 'seosuite.user_email',
      'filename' => 'MODX/Revolution/modSystemSetting/38856978dc9dffab059239c651857239.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2738b841a859482fbda91befb25ab80f',
      'native_key' => 'seosuite.default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/10527aad387275bce6ba9b8b88fd1fac.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bcc19128259ae72fb9a545dbe7cc89eb',
      'native_key' => 'seosuite.default_redirect_type',
      'filename' => 'MODX/Revolution/modSystemSetting/518f04935c7bcc962ef73db88b866e72.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4295d407d734d35d4cfd8eae7adfa762',
      'native_key' => 'seosuite.tab_seo_default_index_type',
      'filename' => 'MODX/Revolution/modSystemSetting/9cec9cd9e526b01c63cfa2a4ad4574ed.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8fb194cc556b8bacb67c068f49d3136d',
      'native_key' => 'seosuite.tab_seo_default_follow_type',
      'filename' => 'MODX/Revolution/modSystemSetting/afc3f8b40887ee4764e47767e9dc4ebb.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b0e9145fea41e9ffece0eb6ccd47b81f',
      'native_key' => 'seosuite.tab_seo_default_sitemap',
      'filename' => 'MODX/Revolution/modSystemSetting/5660c729ad01c1f60881d5d091b0c7b1.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '94bdbf5c9a25bf1089846b75a807c1b6',
      'native_key' => 'seosuite.log_404',
      'filename' => 'MODX/Revolution/modSystemSetting/861d6bab9119685e5eb398edbdd0ec3c.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2397832ae4282a55ba1d3263321d51be',
      'native_key' => 'seosuite.meta.field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/f610dfd8b043e68aefd1a157b83d174d.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b67d2c563048d448d796a15bd0f44aea',
      'native_key' => 'seosuite.meta.default_meta_description',
      'filename' => 'MODX/Revolution/modSystemSetting/44fbc60843df6beab042e675bf64aa59.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20205d7e2b2edff3ddd7bfbe55286025',
      'native_key' => 'seosuite.meta.default_meta_title',
      'filename' => 'MODX/Revolution/modSystemSetting/7b498f8895ba2339367c8152e14ec790.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2acd0b51a31dfdd2e38084dddf583551',
      'native_key' => 'seosuite.meta.default_alternate_context',
      'filename' => 'MODX/Revolution/modSystemSetting/f4dd618417e49da1196b4d55f3dc7bfd.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a2bcc9e6fe09308285d652e6cccebf9e',
      'native_key' => 'seosuite.meta.keywords_field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/410ea8362603e9f1992c49a832811d36.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2319ce78f3a0ff53ec5d1797e4605d9a',
      'native_key' => 'seosuite.meta.preview.length_desktop_description',
      'filename' => 'MODX/Revolution/modSystemSetting/ac26c741431e5498eda689ded1b3257b.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2f40a4591907f4e672c06665fe1b31f8',
      'native_key' => 'seosuite.meta.preview.length_desktop_title',
      'filename' => 'MODX/Revolution/modSystemSetting/15d5f2c99cfe90fa7bac9d51191824b6.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4753fb34c2edb1da5633f0b9a38b5008',
      'native_key' => 'seosuite.meta.preview.length_mobile_description',
      'filename' => 'MODX/Revolution/modSystemSetting/d15b10a472d2042b6d229d8a9bdf92ed.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '59085c7c6768e7c1980641b5aa581b6a',
      'native_key' => 'seosuite.meta.preview.length_mobile_title',
      'filename' => 'MODX/Revolution/modSystemSetting/1392f1b14501d9388ebaf5f8ace353bd.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4a00c3aab6db4686422e85fb5a58c5bb',
      'native_key' => 'seosuite.meta.searchengine',
      'filename' => 'MODX/Revolution/modSystemSetting/75492378ef903dd7a162cdb462af8f0c.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '541c41bf6974c3b5124cebafbed66876',
      'native_key' => 'seosuite.meta.searchmode',
      'filename' => 'MODX/Revolution/modSystemSetting/93907a75b1dd29f2210e437d282d1d20.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '705b4a1ec92d87bcba05108c7fa17699',
      'native_key' => 'seosuite.sitemap.default_changefreq',
      'filename' => 'MODX/Revolution/modSystemSetting/d5990fe3da85c7498abb694185d97109.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '87ae68872aeeeb8c110ab4c4d9458853',
      'native_key' => 'seosuite.sitemap.default_priority',
      'filename' => 'MODX/Revolution/modSystemSetting/215fe5337d6c4381170122a22a58cc85.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe98f1ee2a6404430c4c60b004aef736',
      'native_key' => 'seosuite.sitemap.dependent_ultimateparent',
      'filename' => 'MODX/Revolution/modSystemSetting/e7b9076b56b0e58edb47231210017ef8.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a651473daf40ff6a086adfd8ee55bb6d',
      'native_key' => 'seosuite.sitemap.babel.add_alternate_links',
      'filename' => 'MODX/Revolution/modSystemSetting/643c100a579af5ccb4387f189a718c49.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4428fdc9748f2fdcf71c1050076ece74',
      'native_key' => 'seosuite.tab_social.og_types',
      'filename' => 'MODX/Revolution/modSystemSetting/40fd4d9e74d7ad2a08de8b990d29e656.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2aff87233f0d1d2cc544a2e6f9309f27',
      'native_key' => 'seosuite.tab_social.twitter_cards',
      'filename' => 'MODX/Revolution/modSystemSetting/61d49ca869cacc7062031fb25580e667.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8ec604edbf6fb45b90c028aa255e4c65',
      'native_key' => 'seosuite.tab_social.twitter_creator_id',
      'filename' => 'MODX/Revolution/modSystemSetting/d577daab11fce0c24f524e2a0fd339b5.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e76757cad67da9290ece68dcf1382a35',
      'native_key' => 'seosuite.tab_social.default_og_image',
      'filename' => 'MODX/Revolution/modSystemSetting/f4e237c4922a83095e0e8a67fee32a28.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9c486fead5fe75c85cf2c39321c29baa',
      'native_key' => 'seosuite.tab_social.default_twitter_image',
      'filename' => 'MODX/Revolution/modSystemSetting/b652166676c44a3f38b5208625cc02f4.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3282314c38d83729ff5caef9c69e37a5',
      'native_key' => 'seosuite.panel_position_top',
      'filename' => 'MODX/Revolution/modSystemSetting/ad7cd5f5ca2529116e77785a9a7a6de6.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'dd4755f3d4e69069953498d72bebc2cf',
      'native_key' => 'dd4755f3d4e69069953498d72bebc2cf',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/cf683b45aa472d7b8f452a63a6d3027d.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'faeb1a6d25afe1b57c5daae2d0ab302a',
      'native_key' => 'seosuite.menu.seosuite',
      'filename' => 'MODX/Revolution/modMenu/e661e59a510e2376ceb50637de1862e4.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '5621176586d245c81cddfb60021ff1b0',
      'native_key' => '5621176586d245c81cddfb60021ff1b0',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/5bdc2a326f0794fa61f239763873d3d2.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '6156a3a2d81893c8530829b383516d90',
      'native_key' => '6156a3a2d81893c8530829b383516d90',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/7bbc66821f757ac28ddb4376025aa813.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '4e4927607b980a1ccbd753f2b0eb886f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/ea9ea3616f1234055f7d8a981822338f.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '83c9d7eed4cd63563b59c02685e80b17',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/cfd4f7b00df73bce917ac2e75a61252b.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'a1b2af9d6c7e59fcb75d1470fb0cdf35',
      'native_key' => 'a1b2af9d6c7e59fcb75d1470fb0cdf35',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/754a54689a4355323989c8d0f63c8d99.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'b9f4a55d97b2587932c2669ae0717783',
      'native_key' => 'b9f4a55d97b2587932c2669ae0717783',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/c3d7edd1a8bfa151fe9b7b10d596b69a.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'd592c4899fc31aafab661fb34cda4619',
      'native_key' => 'd592c4899fc31aafab661fb34cda4619',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/6ea6f59aeceeb33c6c48b050373a0646.vehicle',
    ),
  ),
);