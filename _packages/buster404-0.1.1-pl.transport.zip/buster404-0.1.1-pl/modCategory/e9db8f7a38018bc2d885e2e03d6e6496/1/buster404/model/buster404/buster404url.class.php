<?php
/**
 * @package buster404
 */
class Buster404Url extends xPDOSimpleObject {}
?>