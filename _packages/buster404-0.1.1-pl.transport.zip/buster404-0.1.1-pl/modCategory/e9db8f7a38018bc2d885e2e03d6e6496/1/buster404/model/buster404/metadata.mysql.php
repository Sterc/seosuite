<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'Buster404Url',
    1 => 'Buster404Source',
  ),
);