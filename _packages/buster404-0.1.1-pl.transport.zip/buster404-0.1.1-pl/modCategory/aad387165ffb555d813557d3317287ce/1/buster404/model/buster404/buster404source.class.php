<?php
/**
 * @package buster404
 */
class Buster404Source extends xPDOSimpleObject {}
?>