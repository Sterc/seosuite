<?php
/**
 * @package seosuite
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/seosuiteurl.class.php');
class SeoSuiteUrl_mysql extends SeoSuiteUrl {}
