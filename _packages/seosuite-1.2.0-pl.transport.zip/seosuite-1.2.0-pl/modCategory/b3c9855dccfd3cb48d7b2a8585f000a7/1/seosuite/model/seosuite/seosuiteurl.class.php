<?php
/**
 * @package seosuite
 */
class SeoSuiteUrl extends xPDOSimpleObject {}
