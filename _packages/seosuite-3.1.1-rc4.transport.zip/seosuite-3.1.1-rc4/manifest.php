<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'changelog' => 'Changelog for SeoSuite.

SEO Suite 3.1.1
==============
- Fix resolvers for install on MODX3
- PHP8 compatibility fixes
- Add german translation (PR#75)
- Fix spacing in trash icon (fixes #48)
- Fix dashboard widget error (fixes #80)

SEO Suite 3.1.0
==============
- Full refactoring for MODX3 #67

SEO Suite 3.0.5
==============
- Fix changefreq values #60
- Render meta tags on resources created before seosuit was installed #63
- Make sure redirects are 301 by default #73
- Fix error when user have no access to some context #73
- Disable seoTab in install #73

SEO Suite 3.0.4
==============
- Add buttons `Suggestions excludes` and `Logging excludes`

SEO Suite 3.0.3
==============
- Fix blocked_words usage

SEO Suite 3.0.2
==============
- Fix hreflang attribute in alternate tag

SEO Suite 3.0.1
==============
- Fix sorting in CMP
- Fix prority in sitemap

SEO Suite 3.0.0
==============
- Fix MODX 3 compatibility

SEO Suite 2.0.6
==============
- Fix creating redirect when sorting within same parent
- Fixing sitemap settings save on resource tabs
- Fix 500 error when no resource is found

SEO Suite 2.0.5
==============
- Automatically add a 301 redirect when a resource is moved

SEO Suite 2.0.4
==============
- Fix wrong image URL in custom media source #35

SEO Suite 2.0.3
==============
- Skip arrays to avoid tons message in the logs #15
- Fix displaying meta keywords #21
- Replace attribute name to property for og:-metafields #25
- Add russian lexicon #28

SEO Suite 2.0.2
==============
- Fixed issue which caused rich text content fields to break #4 #5

SEO Suite 2.0.1
==============
- Fixed issue which didn\'t set the alternate placeholders properly
- Fixed keyword counter issue in combination with Ace
- Fixed issue which didn\'t save the new url when creating a new redirect
- Fixed incorrect formatted URL during SEO Tab migration
- Added system setting for marking alternate link as x-default

SEO Suite 2.0.0
==============
- Combined SEO Tab, SEO Pro and SEO Suite v1 into one powerful extra
- Added a dedicated SEO panel
- Added Social tab where OG and Twitter meta tags can be managed
- Improved search engine preview

SEO Suite 1.2.3
==============
- Removed license check

SEO Suite 1.2.2
==============
- Added some missing Dutch translations
- Fixed issue with incorrect redirect-cleanup script path
- Improved Dutch/English descriptions

SEO Suite 1.2.1
==============
- validate URL\'s before saving them
- Able to block URL\'s from being saved as redirect by system setting

SEO Suite 1.2.0
==============
- Added redirect created date
- Added redirect triggerd count & last time triggerd date
- Added cleanup cronjob which removes unresolved redirects which are older then 1 month and have been triggered just once

SEO Suite 1.1.2
==============
- Added indexes for improved performance

SEO Suite 1.1.1
==============
- Modstore/modmore compatibility

SEO Suite 1.1.0
==============
- Add limit to redirect suggestions shown in grid
- Add SeoSuiteUrl and try to find matches when OnPageNotFound is triggered and no SeoSuiteUrl object is found
- Add dashboard widget with 10 latest SeoSuite URLs
- Detect CSV file delimiter on import
- Add option to limit matches to related context of URL
- Update find suggestions method to add redirect when one match is found
- Add search by ID to resource combobox
- Add system setting (and cmp field) for excluding words from suggestion matching
- Add suggestions combobox to update url window

SEO Suite 1.0.1
==============
- Fix find-suggestions response message to notify if more than one redirect match
- Fix getSeoTabVersion function to check for correct package_name
- Fix grid getlist to show only first 10 redirect suggestions to prevent processor timeouts
- Fix url update processor to not break when not using SEO Tab as redirect handler

SEO Suite 1.0.0
==============
- Initial release.
',
    'setup-options' => 'seosuite-3.1.1-rc4/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '85b314369bc2d8a8b602e188a759b772',
      'native_key' => 'seosuite',
      'filename' => 'MODX/Revolution/modNamespace/4782f74dcbe8e42cbc4a4e34e47577f6.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bae942c8dfea3a132494e87658997c04',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/9073a883fc2f23fb77d9545a53be4b72.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9a2c4c28c0dcae9740d45d22651a268a',
      'native_key' => 'seosuite.disabled_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/37c2975825c678b2247d8dbd8d7f7cc7.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bdac22662bba954b78cc0b2c840f4882',
      'native_key' => 'seosuite.exclude_words',
      'filename' => 'MODX/Revolution/modSystemSetting/19ca75c29b011b572d7bcb882410afdc.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '97ed19eaa9cff307d293a9b2836d9ba3',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/d57e4ee7a0487c4e890eb190c8b92079.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '467f29aa126cd90c7a6517be340ac1d2',
      'native_key' => 'seosuite.placeholder_plugin_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/13fc3b047877befd7a934332a7f61725.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20b2f24c85ca8768cb0f0dd54ed9607e',
      'native_key' => 'seosuite.migration_finished',
      'filename' => 'MODX/Revolution/modSystemSetting/565eae63346b0dc56bd269477ee3a4ac.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b8dfd21cd8d8b5c5a1255807c6d33f7f',
      'native_key' => 'seosuite.user_name',
      'filename' => 'MODX/Revolution/modSystemSetting/24ff9b9c6b90e94782ed10c9c95288f9.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e6df163440692ed4f545bd777691b580',
      'native_key' => 'seosuite.user_email',
      'filename' => 'MODX/Revolution/modSystemSetting/ea8f93980bbf212fd6623d1f46f126e5.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bbb1c77f004684a26a6b8f07fd96677b',
      'native_key' => 'seosuite.meta.field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/e4bbb9b663654182a47322fce933a904.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e75841fd8c9d3e1b770f06941bb24591',
      'native_key' => 'seosuite.meta.default_meta_description',
      'filename' => 'MODX/Revolution/modSystemSetting/e44e5d833c0e39b56712ca476cd24ac0.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0a7f754e91270e934f461aff824a283a',
      'native_key' => 'seosuite.meta.default_meta_title',
      'filename' => 'MODX/Revolution/modSystemSetting/0f3177e159af76b109f273e6fd45b0cb.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bb5a8cadc241bc2bdc928fe2efe6910f',
      'native_key' => 'seosuite.meta.default_alternate_context',
      'filename' => 'MODX/Revolution/modSystemSetting/231535e1cee1053440bdc9a6ef10952c.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '363bd5f382aad5c6e42e8b1c20f7b72d',
      'native_key' => 'seosuite.meta.keywords_field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/4460e6f0e158b76e717a2bfbf6b7502d.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '365b10a81f4d930dc64b6fe878ec7f94',
      'native_key' => 'seosuite.meta.preview.length_desktop_description',
      'filename' => 'MODX/Revolution/modSystemSetting/fa0c128b3e7e54e12504d4a2731a861b.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '62cb8d7552290da3ece017bc90168588',
      'native_key' => 'seosuite.meta.preview.length_desktop_title',
      'filename' => 'MODX/Revolution/modSystemSetting/bd70422dc74069993e7fb2046130773b.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd687a5fe2bbbedd672fb513d25c45e45',
      'native_key' => 'seosuite.meta.preview.length_mobile_description',
      'filename' => 'MODX/Revolution/modSystemSetting/5f6e6cc7aa586996ee2af2b8b1443e41.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '97aab14c7a810306c1ace4f8f592c829',
      'native_key' => 'seosuite.meta.preview.length_mobile_title',
      'filename' => 'MODX/Revolution/modSystemSetting/04a7b544dd5fbf266ce7949ddf4d28bf.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2fdcccf5e40de1d66be738c82cfd3aac',
      'native_key' => 'seosuite.meta.searchengine',
      'filename' => 'MODX/Revolution/modSystemSetting/4ec26243472e90219263563bcce54162.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f4f4f370a209d4d889e3e4b18f75ef2f',
      'native_key' => 'seosuite.meta.searchmode',
      'filename' => 'MODX/Revolution/modSystemSetting/c1c273792c2f6a891342c0e0bf038d67.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c2727e6accecf3a70b5c9a90003406dc',
      'native_key' => 'seosuite.sitemap.default_changefreq',
      'filename' => 'MODX/Revolution/modSystemSetting/30bed4cbdde838acffb8034418ee44a2.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a60059f3f243707ae5acdda856113a0c',
      'native_key' => 'seosuite.sitemap.default_priority',
      'filename' => 'MODX/Revolution/modSystemSetting/513dd21020ac7e571ae480590eac3edd.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '52c1d532723acf415ebfaba00dd7e8cb',
      'native_key' => 'seosuite.sitemap.dependent_ultimateparent',
      'filename' => 'MODX/Revolution/modSystemSetting/58c79ec0dd897e679d0de52591ab8f66.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '44f63e5be12ff75da6ee435230b9146b',
      'native_key' => 'seosuite.sitemap.babel.add_alternate_links',
      'filename' => 'MODX/Revolution/modSystemSetting/d122c460ee32094a7ca51cc1ed817275.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21c45949a474847b1a30c9495da666e2',
      'native_key' => 'seosuite.tab_social.og_types',
      'filename' => 'MODX/Revolution/modSystemSetting/dd0c6f44f621e407545becdda516ce06.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ca2dcff2961143da2f9b74fa9eb32f34',
      'native_key' => 'seosuite.tab_social.twitter_cards',
      'filename' => 'MODX/Revolution/modSystemSetting/f8810832b0015e15cdeeaae664bd99df.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9582f52b00b4619a776e349953bb6ccd',
      'native_key' => 'seosuite.tab_social.twitter_creator_id',
      'filename' => 'MODX/Revolution/modSystemSetting/3ea388df48fe9d7246e1563a4ff693f7.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b55b167d6d4d63be90efaaf3554d8fac',
      'native_key' => 'seosuite.tab_social.default_og_image',
      'filename' => 'MODX/Revolution/modSystemSetting/65262e8520ea6b887a2668e2b40e16a0.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '45c1c0b6011f9f7cca29870a0d46e63d',
      'native_key' => 'seosuite.tab_social.default_twitter_image',
      'filename' => 'MODX/Revolution/modSystemSetting/3f5acafa19da93b2101be41f1a9f2b12.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '353778461ad7e2215944f66e5cf060c5',
      'native_key' => 'seosuite.menu.seosuite',
      'filename' => 'MODX/Revolution/modMenu/e27fb06370c50eb498ce54c65eb94f28.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '3b59f014188aef1120b7a3c6db8ad00e',
      'native_key' => '3b59f014188aef1120b7a3c6db8ad00e',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/416c24f7bd4144ca54ae2965add7e930.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '3ec5604919ddfdaa5493fc71d29f5eee',
      'native_key' => '3ec5604919ddfdaa5493fc71d29f5eee',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/f11c8cb19ea70e14f435e979f5bee4de.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '473046c12f0a059993b67ad2b1a1d030',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/936693fe28a1d73b69c6252341537a73.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '623bb33e27981984985514a2fcff4696',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/6c90650e071e11dc139444092ac7028a.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'a4f880b349fb80de2a95783a4101f483',
      'native_key' => 'a4f880b349fb80de2a95783a4101f483',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/65d4c4e7977063cce231571ad1d81d01.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '901b880b4c195e78f239577890d33a3e',
      'native_key' => '901b880b4c195e78f239577890d33a3e',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/79c1cdb966fb2e75a2ff261378fb5f30.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '33e6f769058b715eec0a21af32c4ce0e',
      'native_key' => '33e6f769058b715eec0a21af32c4ce0e',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/e4fa71e3d9ec6773b4b291aff2f318ba.vehicle',
    ),
  ),
);