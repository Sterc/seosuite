<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'SeoSuiteSocial',
    1 => 'SeoSuiteUrl',
    2 => 'SeoSuiteResource',
    3 => 'SeoSuiteRedirect',
  ),
);