<?php

/**
 * SeoSuite
 *
 * Copyright 2019 by Sterc <modx@sterc.com>
 */

require_once dirname(__DIR__) . '/seosuiteresource.class.php';

class SeoSuiteResource_mysql extends SeoSuiteResource
{
}
