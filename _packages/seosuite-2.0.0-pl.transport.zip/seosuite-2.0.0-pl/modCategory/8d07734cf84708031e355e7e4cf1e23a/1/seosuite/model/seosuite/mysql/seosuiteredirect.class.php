<?php

/**
 * SeoSuite
 *
 * Copyright 2019 by Sterc <modx@sterc.com>
 */

require_once dirname(__DIR__) . '/seosuiteredirect.class.php';

class SeoSuiteRedirect_mysql extends SeoSuiteRedirect
{
}
