<?php

/**
 * SeoSuite
 *
 * Copyright 2019 by Sterc <modx@sterc.com>
 */

require_once dirname(__DIR__) . '/seosuiteurl.class.php';

class SeoSuiteUrl_mysql extends SeoSuiteUrl
{
}
