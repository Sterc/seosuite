<?php

/**
 * SeoSuite
 *
 * Copyright 2019 by Sterc <modx@sterc.com>
 */

require_once dirname(__DIR__) . '/seosuitesocial.class.php';

class SeoSuiteSocial_mysql extends SeoSuiteSocial
{
}
