<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'changelog' => 'Changelog for SeoSuite.

SEO Suite 3.1.1-rc6
==============
- Fix resolvers for install on MODX3
- PHP8 compatibility fixes
- Add german translation (PR#75)
- Fix spacing in trash icon (fixes #48)
- Fix dashboard widget error (fixes #80)
- Add migration tools to CMP for migrating V1, SEO Pro and SEO Tab.
- Fix table indexes
- Add listener for \'OnBabelDuplicate\'
- Fix default values for sitemap, searchable and canonical

SEO Suite 3.1.0
==============
- Full refactoring for MODX3 #67

SEO Suite 3.0.5
==============
- Fix changefreq values #60
- Render meta tags on resources created before seosuit was installed #63
- Make sure redirects are 301 by default #73
- Fix error when user have no access to some context #73
- Disable seoTab in install #73

SEO Suite 3.0.4
==============
- Add buttons `Suggestions excludes` and `Logging excludes`

SEO Suite 3.0.3
==============
- Fix blocked_words usage

SEO Suite 3.0.2
==============
- Fix hreflang attribute in alternate tag

SEO Suite 3.0.1
==============
- Fix sorting in CMP
- Fix prority in sitemap

SEO Suite 3.0.0
==============
- Fix MODX 3 compatibility

SEO Suite 2.0.6
==============
- Fix creating redirect when sorting within same parent
- Fixing sitemap settings save on resource tabs
- Fix 500 error when no resource is found

SEO Suite 2.0.5
==============
- Automatically add a 301 redirect when a resource is moved

SEO Suite 2.0.4
==============
- Fix wrong image URL in custom media source #35

SEO Suite 2.0.3
==============
- Skip arrays to avoid tons message in the logs #15
- Fix displaying meta keywords #21
- Replace attribute name to property for og:-metafields #25
- Add russian lexicon #28

SEO Suite 2.0.2
==============
- Fixed issue which caused rich text content fields to break #4 #5

SEO Suite 2.0.1
==============
- Fixed issue which didn\'t set the alternate placeholders properly
- Fixed keyword counter issue in combination with Ace
- Fixed issue which didn\'t save the new url when creating a new redirect
- Fixed incorrect formatted URL during SEO Tab migration
- Added system setting for marking alternate link as x-default

SEO Suite 2.0.0
==============
- Combined SEO Tab, SEO Pro and SEO Suite v1 into one powerful extra
- Added a dedicated SEO panel
- Added Social tab where OG and Twitter meta tags can be managed
- Improved search engine preview

SEO Suite 1.2.3
==============
- Removed license check

SEO Suite 1.2.2
==============
- Added some missing Dutch translations
- Fixed issue with incorrect redirect-cleanup script path
- Improved Dutch/English descriptions

SEO Suite 1.2.1
==============
- validate URL\'s before saving them
- Able to block URL\'s from being saved as redirect by system setting

SEO Suite 1.2.0
==============
- Added redirect created date
- Added redirect triggerd count & last time triggerd date
- Added cleanup cronjob which removes unresolved redirects which are older then 1 month and have been triggered just once

SEO Suite 1.1.2
==============
- Added indexes for improved performance

SEO Suite 1.1.1
==============
- Modstore/modmore compatibility

SEO Suite 1.1.0
==============
- Add limit to redirect suggestions shown in grid
- Add SeoSuiteUrl and try to find matches when OnPageNotFound is triggered and no SeoSuiteUrl object is found
- Add dashboard widget with 10 latest SeoSuite URLs
- Detect CSV file delimiter on import
- Add option to limit matches to related context of URL
- Update find suggestions method to add redirect when one match is found
- Add search by ID to resource combobox
- Add system setting (and cmp field) for excluding words from suggestion matching
- Add suggestions combobox to update url window

SEO Suite 1.0.1
==============
- Fix find-suggestions response message to notify if more than one redirect match
- Fix getSeoTabVersion function to check for correct package_name
- Fix grid getlist to show only first 10 redirect suggestions to prevent processor timeouts
- Fix url update processor to not break when not using SEO Tab as redirect handler

SEO Suite 1.0.0
==============
- Initial release.
',
    'setup-options' => 'seosuite-3.1.1-rc7/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '82a94d0d4d48b031ac5e5e97f7dc1865',
      'native_key' => 'seosuite',
      'filename' => 'MODX/Revolution/modNamespace/9041694d371b5486be5ca8725fc1eba7.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2be193fc5c3f44934d927fd8eba91b11',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/013cfca969eb18f1df83e9fa4e948c30.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e87a90b5377a288ed91a4984a624f398',
      'native_key' => 'seosuite.disabled_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/64a9120e71e80c8873b64e0b9843bac3.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '133450612b813e3a6645bcea667ca350',
      'native_key' => 'seosuite.exclude_words',
      'filename' => 'MODX/Revolution/modSystemSetting/c74a28df94ab0f179075202b7058b6ee.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ee4da71fc0182f59ac064703a3d46798',
      'native_key' => 'seosuite.blocked_words',
      'filename' => 'MODX/Revolution/modSystemSetting/b05d2ce6cafe509aa419f16b900ea6f8.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e36d66dc0ce501867fe4eed39eaef460',
      'native_key' => 'seosuite.placeholder_plugin_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/cef4e066572f369e3be0cc0b211063b1.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e59c80dcce88b658f0e52e6e1d984254',
      'native_key' => 'seosuite.migration_finished',
      'filename' => 'MODX/Revolution/modSystemSetting/e9dca776d9da5a4050d601cddd3d0eec.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b579c3100f713034f05d27291420025e',
      'native_key' => 'seosuite.user_name',
      'filename' => 'MODX/Revolution/modSystemSetting/a38408e43b0c60ec10aa41898f437afc.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3344aba0d739b6c0a4e1652ba863752e',
      'native_key' => 'seosuite.user_email',
      'filename' => 'MODX/Revolution/modSystemSetting/42baa181e110ad3c2bb3f4920d5b7fd5.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'de0f278c0d03b126016b2a756df482a6',
      'native_key' => 'seosuite.meta.field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/38cb17edd6bfbb3058cd214d1fbb122d.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bebf8df5a344f16a1809fe7fee14af05',
      'native_key' => 'seosuite.meta.default_meta_description',
      'filename' => 'MODX/Revolution/modSystemSetting/63345949e8a52d9c1eedb7f6f9b9b43b.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '899ad91c35b1b1197b9138356abab681',
      'native_key' => 'seosuite.meta.default_meta_title',
      'filename' => 'MODX/Revolution/modSystemSetting/5b1563d59094103151eb1a62cb6a621b.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c9328e365965e15aa0e17f6339f38333',
      'native_key' => 'seosuite.meta.default_alternate_context',
      'filename' => 'MODX/Revolution/modSystemSetting/fe4cc23d3c534c20d74100e0633271c0.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ead47f82a0410b84a117eb5ee89896ae',
      'native_key' => 'seosuite.meta.keywords_field_counters',
      'filename' => 'MODX/Revolution/modSystemSetting/601a2c1ac3432628c876beb48aa24700.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e7f7ea28a38e57e2f95b09b3fd15f2a5',
      'native_key' => 'seosuite.meta.preview.length_desktop_description',
      'filename' => 'MODX/Revolution/modSystemSetting/607e5d396471e83a864332a3b6dcfe82.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0f209fab19a4a27f9eb0d20de451437b',
      'native_key' => 'seosuite.meta.preview.length_desktop_title',
      'filename' => 'MODX/Revolution/modSystemSetting/ad06797aeaf300f929bc29d7f763e440.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8cf8a909065fad0ba8d627b26d1c3038',
      'native_key' => 'seosuite.meta.preview.length_mobile_description',
      'filename' => 'MODX/Revolution/modSystemSetting/42b809f26e674904dd0511ff3ec27f4d.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '765f61b6a96d0832b61e6d124b0092ed',
      'native_key' => 'seosuite.meta.preview.length_mobile_title',
      'filename' => 'MODX/Revolution/modSystemSetting/42c9381b8f4bcdbeab1acdb2a14d926a.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7d2599ee3ff720f6bb3dceabc1c9d88b',
      'native_key' => 'seosuite.meta.searchengine',
      'filename' => 'MODX/Revolution/modSystemSetting/71558abcefe07f76f720595b78e82788.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7512266270f6c919e9607d18ad3da3c2',
      'native_key' => 'seosuite.meta.searchmode',
      'filename' => 'MODX/Revolution/modSystemSetting/ad34846e9b942abc31382176443990af.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5d93b20dc32fba80ce9b315475666171',
      'native_key' => 'seosuite.sitemap.default_changefreq',
      'filename' => 'MODX/Revolution/modSystemSetting/c429eef09f6ef5ffa63dd52c11c08ddf.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a4ca7dc0e73e14b647258ad6f39b6a3c',
      'native_key' => 'seosuite.sitemap.default_priority',
      'filename' => 'MODX/Revolution/modSystemSetting/1e2d29bdfd2218b5ed7409157b6dd1ba.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd3d65a92d8586e33d9ea66323d521d0a',
      'native_key' => 'seosuite.sitemap.dependent_ultimateparent',
      'filename' => 'MODX/Revolution/modSystemSetting/3123e2d66a81a1e385f509b423aef103.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '04b1815f4220005f0da1bc3c6c4bf389',
      'native_key' => 'seosuite.sitemap.babel.add_alternate_links',
      'filename' => 'MODX/Revolution/modSystemSetting/c08f0b3fb8ab892d1675651f3c50a2f0.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '742a86c925541e423e84e3340c9d1b29',
      'native_key' => 'seosuite.tab_social.og_types',
      'filename' => 'MODX/Revolution/modSystemSetting/b7387b499db6781637b6e95825adf78d.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cebb249fcde36c0a4ba6af3ea01d1bad',
      'native_key' => 'seosuite.tab_social.twitter_cards',
      'filename' => 'MODX/Revolution/modSystemSetting/e53915eec07c2753cd9a75c5c8bfdce7.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6f24ce63cba591673dfef0152c3f63a0',
      'native_key' => 'seosuite.tab_social.twitter_creator_id',
      'filename' => 'MODX/Revolution/modSystemSetting/302d01ff22b7a54a36602d9bc13ea75f.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '439a4de964e81d44881b8bfcce642e7c',
      'native_key' => 'seosuite.tab_social.default_og_image',
      'filename' => 'MODX/Revolution/modSystemSetting/07d977805694c0acd920fba002945262.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e9040e393a46bbb073f5a105528afb8e',
      'native_key' => 'seosuite.tab_social.default_twitter_image',
      'filename' => 'MODX/Revolution/modSystemSetting/6a676ab551fc4d3fbcb98a0e04c44431.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'fe36de221416b5e195afd7e46ac1388c',
      'native_key' => 'seosuite.menu.seosuite',
      'filename' => 'MODX/Revolution/modMenu/63d9b0d0ce6cea0441692e641ab57839.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'b492ca50129a9958241e6f57682cfae5',
      'native_key' => 'b492ca50129a9958241e6f57682cfae5',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/0f6a37646c5d2cafe291711d77ad97aa.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '75275242196562da11a9734d93e0e329',
      'native_key' => '75275242196562da11a9734d93e0e329',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/2e9d2841c554dda8624d571ed3360ae3.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '4915481c538336f28abe7228f7843873',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/af02ae6b6a96b1481c23a494945f7e2b.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '20e04c5526dedd77dc028d7d012c0f1a',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/93aa7dad36ab0486aa9403f490d75d03.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'a8e5f5e332d2c87d3edda8d94f4b98e7',
      'native_key' => 'a8e5f5e332d2c87d3edda8d94f4b98e7',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/4bb37de17fa1f364b1e576501156537d.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'a5802ab86d27cda26f07981627892c03',
      'native_key' => 'a5802ab86d27cda26f07981627892c03',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/48be8b5e17395e17a61f0651865054cc.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'e88b59a63c5c85c9aca2c7c36a4059de',
      'native_key' => 'e88b59a63c5c85c9aca2c7c36a4059de',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/4e392730ac293b95bf987c115e85e5e7.vehicle',
    ),
  ),
);